let serial;
let angles = [0, 0, 0, 0, 0]; // One for each finger
let fingerLength = 100;
let pivotX, pivotY;
let fingerOffsets = []; // Offset angles for fingers to spread out

function setup() {
  createCanvas(windowWidth, windowHeight);
  pivotX = width / 2;
  pivotY = height / 2;

  // Spread fingers nicely
  fingerOffsets = [-30, -15, 0, 15, 30]; // Thumb to pinky
  
  serial = new p5.SerialPort();
  serial.open('/dev/cu.usbmodem11401'); // Replace with your correct port
  serial.on('data', serialEvent);
}

function draw() {
  background(220);
  noFill();
  stroke(0);
  strokeWeight(4);

  // Draw palm (circle)
  fill(200);
  ellipse(pivotX, pivotY, 80, 80);

  // Draw fingers
  for (let i = 0; i < 5; i++) {
    drawFinger(i, angles[i]);
  }
}

function drawFinger(index, angle) {
  push();
  translate(pivotX, pivotY);
  rotate(radians(fingerOffsets[index])); // Spread fingers sideways

  let baseX = 0;
  let baseY = 0;

  // Rotate the individual finger upwards based on angle
  rotate(radians(-angle));

  // Draw the finger
  line(baseX, baseY, 0, -fingerLength);

  // Finger tip (circle)
  fill(100);
  noStroke();
  ellipse(0, -fingerLength, 15, 15);
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function serialEvent() {
  let data = serial.readLine().trim();
  if (data.length > 0) {
    let incoming = data.split(',').map(Number);
    if (incoming.length === 5) {
      angles = incoming;
    }
  }
}
